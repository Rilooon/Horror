using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour
{
    public float speed = 1.0f;

    private void Start()
    {
        float horizontal = Random.Range(-5.0f, 5.0f); 
        float vertical = 0.0f; 

        Vector2 movement = new Vector2(horizontal, vertical) * speed;
        GetComponent<Rigidbody2D>().velocity = movement;
    }

    public float Speed;
    public float OurTime;
    public AnimationCurve AnimCurve;

    private void Update()
    {
        Speed = AnimCurve.Evaluate(OurTime);
        Vector2 move = new Vector2(Speed, 0);
        transform.Translate(move * Time.deltaTime);
        OurTime += Time.deltaTime;
        if (OurTime > 2)
        {
            OurTime = 0;
        }
    }
}
