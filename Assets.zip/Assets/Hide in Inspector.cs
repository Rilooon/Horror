using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharaterStats : MonoBehaviour
{
    [HideInInspector]
    public string ChararcterStatus = "Idle";
    [Header("Personal stats")]
    [SerializeField] private int maximumHP;
    [SerializeField] private int minimumHP;
    private int currentHP;
    [Header("Personal properties")]
    [SerializeField][Range(1,7)] private int _damage;
    [SerializeField][Range(0.5f, 17.3f)][Space] private float _velocity;

}
