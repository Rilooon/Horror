using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSettinScenes : MonoBehaviour
{
    public void LoadSetting()
    {
        SceneManager.LoadSceneAsync(0);
    }
}
