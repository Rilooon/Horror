using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class ExitButton : MonoBehaviour
{

    public Button exitButton;

    void Start()
    {
        exitButton.onClick.AddListener(ExitProgram);
    }

    void ExitProgram()
    {
        Application.Quit();
    }
}