using UnityEngine;
using System.Collections;

public class DisappearOnContact : MonoBehaviour
{
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            rb.isKinematic = true; 
            gameObject.SetActive(false); 
        }
    }
}
